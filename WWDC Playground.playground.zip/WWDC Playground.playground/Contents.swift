import UIKit
import CoreML
import AVKit
import Vision
import AVFoundation
import PlaygroundSupport
//Money Classifier
/// Model Prediction Input Type
@available(macOS 10.13, iOS 11.0, tvOS 11.0, watchOS 4.0, *)
class MoneyClassifierInput : MLFeatureProvider {
    
    /// Input image to be classified as color (kCVPixelFormatType_32BGRA) image buffer, 299 pixels wide by 299 pixels high
    var image: CVPixelBuffer
    
    var featureNames: Set<String> {
        get {
            return ["image"]
        }
    }
    
    func featureValue(for featureName: String) -> MLFeatureValue? {
        if (featureName == "image") {
            return MLFeatureValue(pixelBuffer: image)
        }
        return nil
    }
    
    init(image: CVPixelBuffer) {
        self.image = image
    }
}

/// Model Prediction Output Type
@available(macOS 10.13, iOS 11.0, tvOS 11.0, watchOS 4.0, *)
class MoneyClassifierOutput : MLFeatureProvider {
    
    /// Source provided by CoreML
    
    private let provider : MLFeatureProvider
    
    
    /// Probability of each category as dictionary of strings to doubles
    lazy var classLabelProbs: [String : Double] = {
        [unowned self] in return self.provider.featureValue(for: "classLabelProbs")!.dictionaryValue as! [String : Double]
        }()
    
    /// Most likely image category as string value
    lazy var classLabel: String = {
        [unowned self] in return self.provider.featureValue(for: "classLabel")!.stringValue
        }()
    
    var featureNames: Set<String> {
        return self.provider.featureNames
    }
    
    func featureValue(for featureName: String) -> MLFeatureValue? {
        return self.provider.featureValue(for: featureName)
    }
    
    init(classLabelProbs: [String : Double], classLabel: String) {
        self.provider = try! MLDictionaryFeatureProvider(dictionary: ["classLabelProbs" : MLFeatureValue(dictionary: classLabelProbs as [AnyHashable : NSNumber]), "classLabel" : MLFeatureValue(string: classLabel)])
    }
    
    init(features: MLFeatureProvider) {
        self.provider = features
    }
}


/// Class for model loading and prediction
@available(macOS 10.13, iOS 11.0, tvOS 11.0, watchOS 4.0, *)
class MoneyClassifier {
    var model: MLModel
    
    /// URL of model assuming it was installed in the same bundle as this class
    class var urlOfModelInThisBundle : URL {
        let bundle = Bundle(for: MoneyClassifier.self)
        return bundle.url(forResource: "MoneyClassifier", withExtension:"mlmodelc")!
    }
    
    /**
     Construct a model with explicit path to mlmodelc file
     - parameters:
     - url: the file url of the model
     - throws: an NSError object that describes the problem
     */
    init(contentsOf url: URL) throws {
        self.model = try MLModel(contentsOf: url)
    }
    
    /// Construct a model that automatically loads the model from the app's bundle
    convenience init() {
        try! self.init(contentsOf: type(of:self).urlOfModelInThisBundle)
    }
    
    /**
     Construct a model with configuration
     - parameters:
     - configuration: the desired model configuration
     - throws: an NSError object that describes the problem
     */
    @available(macOS 10.14, iOS 12.0, tvOS 12.0, watchOS 5.0, *)
    convenience init(configuration: MLModelConfiguration) throws {
        try self.init(contentsOf: type(of:self).urlOfModelInThisBundle, configuration: configuration)
    }
    
    /**
     Construct a model with explicit path to mlmodelc file and configuration
     - parameters:
     - url: the file url of the model
     - configuration: the desired model configuration
     - throws: an NSError object that describes the problem
     */
    @available(macOS 10.14, iOS 12.0, tvOS 12.0, watchOS 5.0, *)
    init(contentsOf url: URL, configuration: MLModelConfiguration) throws {
        self.model = try MLModel(contentsOf: url, configuration: configuration)
    }
    
    /**
     Make a prediction using the structured interface
     - parameters:
     - input: the input to the prediction as MoneyClassifierInput
     - throws: an NSError object that describes the problem
     - returns: the result of the prediction as MoneyClassifierOutput
     */
    func prediction(input: MoneyClassifierInput) throws -> MoneyClassifierOutput {
        return try self.prediction(input: input, options: MLPredictionOptions())
    }
    
    /**
     Make a prediction using the structured interface
     - parameters:
     - input: the input to the prediction as MoneyClassifierInput
     - options: prediction options
     - throws: an NSError object that describes the problem
     - returns: the result of the prediction as MoneyClassifierOutput
     */
    func prediction(input: MoneyClassifierInput, options: MLPredictionOptions) throws -> MoneyClassifierOutput {
        let outFeatures = try model.prediction(from: input, options:options)
        return MoneyClassifierOutput(features: outFeatures)
    }
    
    /**
     Make a prediction using the convenience interface
     - parameters:
     - image: Input image to be classified as color (kCVPixelFormatType_32BGRA) image buffer, 299 pixels wide by 299 pixels high
     - throws: an NSError object that describes the problem
     - returns: the result of the prediction as MoneyClassifierOutput
     */
    func prediction(image: CVPixelBuffer) throws -> MoneyClassifierOutput {
        let input_ = MoneyClassifierInput(image: image)
        return try self.prediction(input: input_)
    }
    
    /**
     Make a batch prediction using the structured interface
     - parameters:
     - inputs: the inputs to the prediction as [MoneyClassifierInput]
     - options: prediction options
     - throws: an NSError object that describes the problem
     - returns: the result of the prediction as [MoneyClassifierOutput]
     */
    @available(macOS 10.14, iOS 12.0, tvOS 12.0, watchOS 5.0, *)
    func predictions(inputs: [MoneyClassifierInput], options: MLPredictionOptions = MLPredictionOptions()) throws -> [MoneyClassifierOutput] {
        let batchIn = MLArrayBatchProvider(array: inputs)
        let batchOut = try model.predictions(from: batchIn, options: options)
        var results : [MoneyClassifierOutput] = []
        results.reserveCapacity(inputs.count)
        for i in 0..<batchOut.count {
            let outProvider = batchOut.features(at: i)
            let result =  MoneyClassifierOutput(features: outProvider)
            results.append(result)
        }
        return results
    }
}



// MOBILE NET MODEL
/// Model Prediction Input Type
@available(macOS 10.13, iOS 11.0, tvOS 11.0, watchOS 4.0, *)
class MobileNetInput : MLFeatureProvider {
    
    /// Input image to be classified as color (kCVPixelFormatType_32BGRA) image buffer, 224 pixels wide by 224 pixels high
    var image: CVPixelBuffer
    
    var featureNames: Set<String> {
        get {
            return ["image"]
        }
    }
    
    func featureValue(for featureName: String) -> MLFeatureValue? {
        if (featureName == "image") {
            return MLFeatureValue(pixelBuffer: image)
        }
        return nil
    }
    
    init(image: CVPixelBuffer) {
        self.image = image
    }
}

/// Model Prediction Output Type
@available(macOS 10.13, iOS 11.0, tvOS 11.0, watchOS 4.0, *)
class MobileNetOutput : MLFeatureProvider {
    
    /// Source provided by CoreML
    
    private let provider : MLFeatureProvider
    
    
    /// Probability of each category as dictionary of strings to doubles
    lazy var classLabelProbs: [String : Double] = {
        [unowned self] in return self.provider.featureValue(for: "classLabelProbs")!.dictionaryValue as! [String : Double]
        }()
    
    /// Most likely image category as string value
    lazy var classLabel: String = {
        [unowned self] in return self.provider.featureValue(for: "classLabel")!.stringValue
        }()
    
    var featureNames: Set<String> {
        return self.provider.featureNames
    }
    
    func featureValue(for featureName: String) -> MLFeatureValue? {
        return self.provider.featureValue(for: featureName)
    }
    
    init(classLabelProbs: [String : Double], classLabel: String) {
        self.provider = try! MLDictionaryFeatureProvider(dictionary: ["classLabelProbs" : MLFeatureValue(dictionary: classLabelProbs as [AnyHashable : NSNumber]), "classLabel" : MLFeatureValue(string: classLabel)])
    }
    
    init(features: MLFeatureProvider) {
        self.provider = features
    }
}


/// Class for model loading and prediction
@available(macOS 10.13, iOS 11.0, tvOS 11.0, watchOS 4.0, *)
class MobileNet {
    var model: MLModel
    
    /// URL of model assuming it was installed in the same bundle as this class
    class var urlOfModelInThisBundle : URL {
        let bundle = Bundle(for: MobileNet.self)
        return bundle.url(forResource: "MobileNet", withExtension:"mlmodelc")!
    }
    
    /**
     Construct a model with explicit path to mlmodelc file
     - parameters:
     - url: the file url of the model
     - throws: an NSError object that describes the problem
     */
    init(contentsOf url: URL) throws {
        self.model = try MLModel(contentsOf: url)
    }
    
    /// Construct a model that automatically loads the model from the app's bundle
    convenience init() {
        try! self.init(contentsOf: type(of:self).urlOfModelInThisBundle)
    }
    
    /**
     Construct a model with configuration
     - parameters:
     - configuration: the desired model configuration
     - throws: an NSError object that describes the problem
     */
    @available(macOS 10.14, iOS 12.0, tvOS 12.0, watchOS 5.0, *)
    convenience init(configuration: MLModelConfiguration) throws {
        try self.init(contentsOf: type(of:self).urlOfModelInThisBundle, configuration: configuration)
    }
    
    /**
     Construct a model with explicit path to mlmodelc file and configuration
     - parameters:
     - url: the file url of the model
     - configuration: the desired model configuration
     - throws: an NSError object that describes the problem
     */
    @available(macOS 10.14, iOS 12.0, tvOS 12.0, watchOS 5.0, *)
    init(contentsOf url: URL, configuration: MLModelConfiguration) throws {
        self.model = try MLModel(contentsOf: url, configuration: configuration)
    }
    
    /**
     Make a prediction using the structured interface
     - parameters:
     - input: the input to the prediction as MobileNetInput
     - throws: an NSError object that describes the problem
     - returns: the result of the prediction as MobileNetOutput
     */
    func prediction(input: MobileNetInput) throws -> MobileNetOutput {
        return try self.prediction(input: input, options: MLPredictionOptions())
    }
    
    /**
     Make a prediction using the structured interface
     - parameters:
     - input: the input to the prediction as MobileNetInput
     - options: prediction options
     - throws: an NSError object that describes the problem
     - returns: the result of the prediction as MobileNetOutput
     */
    func prediction(input: MobileNetInput, options: MLPredictionOptions) throws -> MobileNetOutput {
        let outFeatures = try model.prediction(from: input, options:options)
        return MobileNetOutput(features: outFeatures)
    }
    
    /**
     Make a prediction using the convenience interface
     - parameters:
     - image: Input image to be classified as color (kCVPixelFormatType_32BGRA) image buffer, 224 pixels wide by 224 pixels high
     - throws: an NSError object that describes the problem
     - returns: the result of the prediction as MobileNetOutput
     */
    func prediction(image: CVPixelBuffer) throws -> MobileNetOutput {
        let input_ = MobileNetInput(image: image)
        return try self.prediction(input: input_)
    }
    
    /**
     Make a batch prediction using the structured interface
     - parameters:
     - inputs: the inputs to the prediction as [MobileNetInput]
     - options: prediction options
     - throws: an NSError object that describes the problem
     - returns: the result of the prediction as [MobileNetOutput]
     */
    @available(macOS 10.14, iOS 12.0, tvOS 12.0, watchOS 5.0, *)
    func predictions(inputs: [MobileNetInput], options: MLPredictionOptions = MLPredictionOptions()) throws -> [MobileNetOutput] {
        let batchIn = MLArrayBatchProvider(array: inputs)
        let batchOut = try model.predictions(from: batchIn, options: options)
        var results : [MobileNetOutput] = []
        results.reserveCapacity(inputs.count)
        for i in 0..<batchOut.count {
            let outProvider = batchOut.features(at: i)
            let result =  MobileNetOutput(features: outProvider)
            results.append(result)
        }
        return results
    }
}









/// Model Prediction Input Type
@available(macOS 10.13, iOS 11.0, tvOS 11.0, watchOS 4.0, *)
class ASLModelInput : MLFeatureProvider {
    
    /// Input image to be classified as color (kCVPixelFormatType_32BGRA) image buffer, 299 pixels wide by 299 pixels high
    var image: CVPixelBuffer
    
    var featureNames: Set<String> {
        get {
            return ["image"]
        }
    }
    
    func featureValue(for featureName: String) -> MLFeatureValue? {
        if (featureName == "image") {
            return MLFeatureValue(pixelBuffer: image)
        }
        return nil
    }
    
    init(image: CVPixelBuffer) {
        self.image = image
    }
}

/// Model Prediction Output Type
@available(macOS 10.13, iOS 11.0, tvOS 11.0, watchOS 4.0, *)
class ASLModelOutput : MLFeatureProvider {
    
    /// Source provided by CoreML
    
    private let provider : MLFeatureProvider
    
    
    /// Probability of each category as dictionary of strings to doubles
    lazy var classLabelProbs: [String : Double] = {
        [unowned self] in return self.provider.featureValue(for: "classLabelProbs")!.dictionaryValue as! [String : Double]
        }()
    
    /// Most likely image category as string value
    lazy var classLabel: String = {
        [unowned self] in return self.provider.featureValue(for: "classLabel")!.stringValue
        }()
    
    var featureNames: Set<String> {
        return self.provider.featureNames
    }
    
    func featureValue(for featureName: String) -> MLFeatureValue? {
        return self.provider.featureValue(for: featureName)
    }
    
    init(classLabelProbs: [String : Double], classLabel: String) {
        self.provider = try! MLDictionaryFeatureProvider(dictionary: ["classLabelProbs" : MLFeatureValue(dictionary: classLabelProbs as [AnyHashable : NSNumber]), "classLabel" : MLFeatureValue(string: classLabel)])
    }
    
    init(features: MLFeatureProvider) {
        self.provider = features
    }
}

/// Model Prediction Input Type
@available(macOS 10.13, iOS 11.0, tvOS 11.0, watchOS 4.0, *)
class ASLInput : MLFeatureProvider {
    
    /// Input image to be classified as color (kCVPixelFormatType_32BGRA) image buffer, 299 pixels wide by 299 pixels high
    var image: CVPixelBuffer
    
    var featureNames: Set<String> {
        get {
            return ["image"]
        }
    }
    
    func featureValue(for featureName: String) -> MLFeatureValue? {
        if (featureName == "image") {
            return MLFeatureValue(pixelBuffer: image)
        }
        return nil
    }
    
    init(image: CVPixelBuffer) {
        self.image = image
    }
}

/// Model Prediction Output Type
@available(macOS 10.13, iOS 11.0, tvOS 11.0, watchOS 4.0, *)
class ASLOutput : MLFeatureProvider {
    
    /// Source provided by CoreML
    
    private let provider : MLFeatureProvider
    
    
    /// Probability of each category as dictionary of strings to doubles
    lazy var classLabelProbs: [String : Double] = {
        [unowned self] in return self.provider.featureValue(for: "classLabelProbs")!.dictionaryValue as! [String : Double]
        }()
    
    /// Most likely image category as string value
    lazy var classLabel: String = {
        [unowned self] in return self.provider.featureValue(for: "classLabel")!.stringValue
        }()
    
    var featureNames: Set<String> {
        return self.provider.featureNames
    }
    
    func featureValue(for featureName: String) -> MLFeatureValue? {
        return self.provider.featureValue(for: featureName)
    }
    
    init(classLabelProbs: [String : Double], classLabel: String) {
        self.provider = try! MLDictionaryFeatureProvider(dictionary: ["classLabelProbs" : MLFeatureValue(dictionary: classLabelProbs as [AnyHashable : NSNumber]), "classLabel" : MLFeatureValue(string: classLabel)])
    }
    
    init(features: MLFeatureProvider) {
        self.provider = features
    }
}


/// Class for model loading and prediction
@available(macOS 10.13, iOS 11.0, tvOS 11.0, watchOS 4.0, *)
class ASL {
    var model: MLModel
    
    /// URL of model assuming it was installed in the same bundle as this class
    class var urlOfModelInThisBundle : URL {
        let bundle = Bundle(for: ASL.self)
        return bundle.url(forResource: "ASL", withExtension:"mlmodelc")!
    }
    
    /**
     Construct a model with explicit path to mlmodelc file
     - parameters:
     - url: the file url of the model
     - throws: an NSError object that describes the problem
     */
    init(contentsOf url: URL) throws {
        self.model = try MLModel(contentsOf: url)
    }
    
    /// Construct a model that automatically loads the model from the app's bundle
    convenience init() {
        try! self.init(contentsOf: type(of:self).urlOfModelInThisBundle)
    }
    
    /**
     Construct a model with configuration
     - parameters:
     - configuration: the desired model configuration
     - throws: an NSError object that describes the problem
     */
    @available(macOS 10.14, iOS 12.0, tvOS 12.0, watchOS 5.0, *)
    convenience init(configuration: MLModelConfiguration) throws {
        try self.init(contentsOf: type(of:self).urlOfModelInThisBundle, configuration: configuration)
    }
    
    /**
     Construct a model with explicit path to mlmodelc file and configuration
     - parameters:
     - url: the file url of the model
     - configuration: the desired model configuration
     - throws: an NSError object that describes the problem
     */
    @available(macOS 10.14, iOS 12.0, tvOS 12.0, watchOS 5.0, *)
    init(contentsOf url: URL, configuration: MLModelConfiguration) throws {
        self.model = try MLModel(contentsOf: url, configuration: configuration)
    }
    
    /**
     Make a prediction using the structured interface
     - parameters:
     - input: the input to the prediction as ASLInput
     - throws: an NSError object that describes the problem
     - returns: the result of the prediction as ASLOutput
     */
    func prediction(input: ASLInput) throws -> ASLOutput {
        return try self.prediction(input: input, options: MLPredictionOptions())
    }
    
    /**
     Make a prediction using the structured interface
     - parameters:
     - input: the input to the prediction as ASLInput
     - options: prediction options
     - throws: an NSError object that describes the problem
     - returns: the result of the prediction as ASLOutput
     */
    func prediction(input: ASLInput, options: MLPredictionOptions) throws -> ASLOutput {
        let outFeatures = try model.prediction(from: input, options:options)
        return ASLOutput(features: outFeatures)
    }
    
    /**
     Make a prediction using the convenience interface
     - parameters:
     - image: Input image to be classified as color (kCVPixelFormatType_32BGRA) image buffer, 299 pixels wide by 299 pixels high
     - throws: an NSError object that describes the problem
     - returns: the result of the prediction as ASLOutput
     */
    func prediction(image: CVPixelBuffer) throws -> ASLOutput {
        let input_ = ASLInput(image: image)
        return try self.prediction(input: input_)
    }
    
    /**
     Make a batch prediction using the structured interface
     - parameters:
     - inputs: the inputs to the prediction as [ASLInput]
     - options: prediction options
     - throws: an NSError object that describes the problem
     - returns: the result of the prediction as [ASLOutput]
     */
    @available(macOS 10.14, iOS 12.0, tvOS 12.0, watchOS 5.0, *)
    func predictions(inputs: [ASLInput], options: MLPredictionOptions = MLPredictionOptions()) throws -> [ASLOutput] {
        let batchIn = MLArrayBatchProvider(array: inputs)
        let batchOut = try model.predictions(from: batchIn, options: options)
        var results : [ASLOutput] = []
        results.reserveCapacity(inputs.count)
        for i in 0..<batchOut.count {
            let outProvider = batchOut.features(at: i)
            let result =  ASLOutput(features: outProvider)
            results.append(result)
        }
        return results
    }
}


//MARK: MAIN VIEW CONTROLLER
class navigationController: UINavigationController{
    override func viewDidLoad() {
        navigationBar.isTranslucent = false
        navigationBar.tintColor = .white
        navigationBar.barStyle = .black
        navigationBar.prefersLargeTitles = true
        navigationBar.barTintColor = #colorLiteral(red: 0.5405443149, green: 0.1378519087, blue: 0.8, alpha: 1)
        navigationBar.shadowImage = nil
        navigationBar.setValue(true, forKey: "hidesShadow")
    }
}
class mainViewController: UIViewController{
    //Declare Variables
    var containerView: UIView = {
        let view = UIView()
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    var ASLLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont(name: "HelveticaNeue-Bold", size: 35)
        label.text = "POWER THE POWERLESS 🙌 "
        label.lineBreakMode = NSLineBreakMode.byClipping
        label.textColor  = .white
        label.textAlignment = .center
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    var buttonContainerView: UIView = {
        let view = UIView()
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    var buttonDeaf: UIButton = {
        let button = UIButton()
        button.setTitle("Deaf👂", for: .normal)
        button.setTitleColor(#colorLiteral(red: 0.1176470588, green: 0.1647058824, blue: 0.8235294118, alpha: 1), for: .normal)
        button.backgroundColor = .white
        button.translatesAutoresizingMaskIntoConstraints = false
        button.addTarget(self, action: #selector(openVCForDeaf), for: .touchUpInside)
        button.titleLabel?.font = UIFont(name: "HelveticaNeue-Bold", size: 20)
        button.layer.cornerRadius = 25
        return button
    }()
    var buttonBlind: UIButton = {
        let button = UIButton()
        button.setTitle("Blind👁", for: .normal)
        button.setTitleColor(#colorLiteral(red: 0.1176470588, green: 0.1647058824, blue: 0.8235294118, alpha: 1), for: .normal)
        button.backgroundColor = .white
        button.translatesAutoresizingMaskIntoConstraints = false
        button.addTarget(self, action: #selector(openVCForBlind), for: .touchUpInside)
        button.titleLabel?.font = UIFont(name: "HelveticaNeue-Bold", size: 20)
        button.layer.cornerRadius = 25
        return button
    }()
    var buttonMute: UIButton = {
        let button = UIButton()
        button.setTitle("Mute🗣", for: .normal)
        button.setTitleColor(#colorLiteral(red: 0.1176470588, green: 0.1647058824, blue: 0.8235294118, alpha: 1), for: .normal)
        button.backgroundColor = .white
        button.translatesAutoresizingMaskIntoConstraints = false
        button.addTarget(self, action: #selector(openVCForMute), for: .touchUpInside)
        button.titleLabel?.font = UIFont(name: "HelveticaNeue-Bold", size: 20)
        button.layer.cornerRadius = 25
        return button
    }()
    let gradientLayer = CAGradientLayer()
    override func viewDidLoad() {
        gradientLayer.colors = [#colorLiteral(red: 1, green: 0.6509803922, blue: 0.7176470588, alpha: 1).cgColor, #colorLiteral(red: 0.1176470588, green: 0.1647058824, blue: 0.8235294118, alpha: 1).cgColor]
        gradientLayer.startPoint = CGPoint(x: 1, y: 0)
        gradientLayer.endPoint = CGPoint(x: 0, y: 1)
        gradientLayer.frame = self.view.bounds
        self.view.layer.addSublayer(gradientLayer)
        self.view.backgroundColor = .white
        setUpUIView()
    }
    override func viewWillDisappear(_ animated: Bool) {
        navigationController?.navigationBar.isHidden = false
    }
    override func viewWillAppear(_ animated: Bool) {
        navigationController?.navigationBar.isHidden = true
    }
    func setUpUIView(){
        view.addSubview(containerView)
        containerView.addSubview(ASLLabel)
        
        containerView.addSubview(buttonContainerView)
        buttonContainerView.addSubview(buttonDeaf)
        buttonContainerView.addSubview(buttonBlind)
        buttonContainerView.addSubview(buttonMute)

        NSLayoutConstraint.activate([
            
            containerView.centerXAnchor.constraint(equalTo: view.safeAreaLayoutGuide.centerXAnchor),
            containerView.centerYAnchor.constraint(equalTo: view.safeAreaLayoutGuide.centerYAnchor),
            containerView.widthAnchor.constraint(equalTo: view.safeAreaLayoutGuide.widthAnchor),
            containerView.heightAnchor.constraint(equalToConstant: 300),
            
            ASLLabel.centerXAnchor.constraint(equalTo: containerView.centerXAnchor),
            ASLLabel.topAnchor.constraint(equalTo: containerView.topAnchor),
            ASLLabel.widthAnchor.constraint(equalTo: containerView.widthAnchor),
            ASLLabel.heightAnchor.constraint(equalToConstant: 100),
            
            buttonContainerView.centerXAnchor.constraint(equalTo: view.safeAreaLayoutGuide.centerXAnchor),
            buttonContainerView.topAnchor.constraint(equalTo: ASLLabel.bottomAnchor),
            buttonContainerView.widthAnchor.constraint(equalTo: view.safeAreaLayoutGuide.widthAnchor),
            buttonContainerView.heightAnchor.constraint(equalToConstant: 200),
            
            buttonDeaf.topAnchor.constraint(equalTo: buttonContainerView.topAnchor),
            buttonDeaf.centerXAnchor.constraint(equalTo: buttonContainerView.centerXAnchor),
            buttonDeaf.widthAnchor.constraint(equalToConstant: 270),
            buttonDeaf.heightAnchor.constraint(equalTo: buttonContainerView.heightAnchor, multiplier: 1/4),
        
            buttonBlind.topAnchor.constraint(equalTo: buttonDeaf.bottomAnchor, constant: 10),
            buttonBlind.centerXAnchor.constraint(equalTo: buttonContainerView.centerXAnchor),
            buttonBlind.widthAnchor.constraint(equalToConstant: 270),
            buttonBlind.heightAnchor.constraint(equalTo: buttonContainerView.heightAnchor, multiplier: 1/4),
            
            buttonMute.topAnchor.constraint(equalTo: buttonBlind.bottomAnchor, constant: 10),
            buttonMute.centerXAnchor.constraint(equalTo: buttonContainerView.centerXAnchor),
            buttonMute.widthAnchor.constraint(equalToConstant: 270),
            buttonMute.heightAnchor.constraint(equalTo: buttonContainerView.heightAnchor, multiplier: 1/4)
            
        ])
    }
    @objc func openVCForDeaf(){
    navigationController?.pushViewController(SignToTextViewController(), animated: true)
    }
    @objc func openVCForBlind(){
        navigationController?.pushViewController(VCForBlind(), animated: true)
    }
    @objc func openVCForMute(){
        navigationController?.pushViewController(VCforMute(), animated: true)
    }
}
class VCforMute: UIViewController{
    let titleLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = UIFont.boldSystemFont(ofSize: 30)
        label.text = "Voice the voiceless"
        return label
    }()
    let descriptionTextView: UITextView = {
        let textView = UITextView()
        textView.translatesAutoresizingMaskIntoConstraints = false
        textView.text = "Type in text below and press the button to start speaking!"
        textView.backgroundColor = .clear
        textView.isEditable = false
        return textView
    }()
    let textView: UITextView = {
        let textView = UITextView()
        textView.translatesAutoresizingMaskIntoConstraints = false
        textView.layer.cornerRadius = 12
        textView.layer.shadowColor = UIColor.black.cgColor
        textView.layer.shadowOpacity = 0.5
        textView.layer.shadowOffset = CGSize.zero
        textView.layer.shadowRadius = 7
        textView.layer.masksToBounds = false
        return textView
    }()
    let speakButton: UIButton = {
        let button = UIButton()
        button.backgroundColor = #colorLiteral(red: 0.5405443149, green: 0.1378519087, blue: 0.8, alpha: 1)
        button.titleLabel?.font = UIFont(name: "HelveticaNeue-Bold", size: 20)
        button.setTitle("🗣", for: .normal)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.addTarget(self, action: #selector(speak), for: .touchUpInside)
        button.layer.cornerRadius = 30
        return button
    }()
    override func viewDidLoad() {
        title = "Text To Speech"
        setUpUI()
    }
    var speakButtonWidth: NSLayoutConstraint?
    func setUpUI() {
        view.backgroundColor = .white
        view.addSubview(titleLabel)
        view.addSubview(descriptionTextView)
        view.addSubview(textView)
        view.addSubview(speakButton)
        
        speakButtonWidth = speakButton.widthAnchor.constraint(equalToConstant: 60)
        NSLayoutConstraint.activate([
            titleLabel.centerXAnchor.constraint(equalTo: view.safeAreaLayoutGuide.centerXAnchor),
            titleLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            titleLabel.widthAnchor.constraint(equalTo: view.safeAreaLayoutGuide.widthAnchor, constant: -36),
            titleLabel.heightAnchor.constraint(equalToConstant: 60),
            
            descriptionTextView.centerXAnchor.constraint(equalTo: view.safeAreaLayoutGuide.centerXAnchor),
            descriptionTextView.topAnchor.constraint(equalTo: titleLabel.bottomAnchor),
            descriptionTextView.widthAnchor.constraint(equalTo: view.safeAreaLayoutGuide.widthAnchor, constant: -36),
            descriptionTextView.heightAnchor.constraint(equalToConstant: 50),
            
            textView.centerXAnchor.constraint(equalTo: view.safeAreaLayoutGuide.centerXAnchor),
            textView.topAnchor.constraint(equalTo: descriptionTextView.bottomAnchor),
            textView.widthAnchor.constraint(equalTo: view.safeAreaLayoutGuide.widthAnchor, constant: -36),
            textView.heightAnchor.constraint(equalToConstant: 200),
            
            speakButton.centerXAnchor.constraint(equalTo: view.safeAreaLayoutGuide.centerXAnchor),
            speakButton.topAnchor.constraint(equalTo: textView.bottomAnchor, constant:5),
            speakButtonWidth!,
            speakButton.heightAnchor.constraint(equalToConstant: 60),
            ])
    }
    @objc func speak(){
        if speechSynthesizer.isSpeaking{
            speechSynthesizer.stopSpeaking(at: .immediate)
            speechAndText(text: textView.text)
        }
        else{
            speechAndText(text: textView.text)
        }
    }
    let speechSynthesizer = AVSpeechSynthesizer()
    
    func speechAndText(text: String) {
        let speechUtterance = AVSpeechUtterance(string: text)
        speechSynthesizer.speak(speechUtterance)
        UIView.animate(withDuration: 1.0, delay: 0.0, options: .curveEaseInOut, animations: {
        }, completion: nil)
    }

}
class VCForBlind: UIViewController{
    let titleLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = UIFont.boldSystemFont(ofSize: 30)
        label.textColor = .white
        label.text = "Welcome!"
        label.textAlignment = .center
        return label
    }()
    let descriptionTextView: UITextView = {
        let textView = UITextView()
        textView.translatesAutoresizingMaskIntoConstraints = false
        textView.text = "In the world, today, there are over 285 million blind people. This playground is programmed to help the blind. The following features are created to assist them."
        textView.backgroundColor = .clear
        textView.textColor = .white
        return textView
    }()
    let objectToVoiceTitleLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = UIFont.boldSystemFont(ofSize: 20)
        label.textColor = .white
        label.text = "Object to Voice"
        label.textAlignment = .center
        return label
    }()
    let objectToVoiceTDescriptionTextView: UITextView = {
        let textView = UITextView()
        textView.translatesAutoresizingMaskIntoConstraints = false
        textView.text = "Let us be your eyes! Point the device at any object and we'll identify it and translate it to speech! Swipe down or press the button below to expierence this feature"
        textView.backgroundColor = .clear
        textView.textColor = .white
        return textView
    }()
    var objectToVoiceButton: UIButton = {
        let button = UIButton()
        button.setTitle("Object to Voice", for: .normal)
        button.setTitleColor(#colorLiteral(red: 0.3137254902, green: 0.6784313725, blue: 0.6588235294, alpha: 1), for: .normal)
        button.backgroundColor = .white
        button.addTarget(self, action: #selector(showObjectToTextVC), for: .touchUpInside)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.titleLabel?.font = UIFont(name: "HelveticaNeue-Bold", size: 15)
        button.layer.cornerRadius = 20
        return button
    }()
    let moneyIdentifierTitleLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = UIFont.boldSystemFont(ofSize: 20)
        label.textColor = .white
        label.text = "Money Identifier"
        label.textAlignment = .center
        return label
    }()
    let moneyIdentifierDescriptionTextView: UITextView = {
        let textView = UITextView()
        textView.translatesAutoresizingMaskIntoConstraints = false
        textView.text = "Never let anyone deceive you ever again. Scan the your dollar bills and the application will identify its worth and let you know. Swipe up or press the button below to start"
        textView.backgroundColor = .clear
        textView.textColor = .white
        return textView
    }()
    var moneyIdentifierTextTButton: UIButton = {
        let button = UIButton()
        button.setTitle("Money Identifier", for: .normal)
        button.setTitleColor(#colorLiteral(red: 0.3137254902, green: 0.6784313725, blue: 0.6588235294, alpha: 1), for: .normal)
        button.backgroundColor = .white
        button.translatesAutoresizingMaskIntoConstraints = false
        button.titleLabel?.font = UIFont(name: "HelveticaNeue-Bold", size: 15)
        button.addTarget(self, action: #selector(showMoneyIdentifierVC), for: .touchUpInside)
        button.layer.cornerRadius = 20
        return button
    }()
    override func viewDidLoad() {
        setUp()
        introductionVoice()
    }
    func introductionVoice(){
        speechAndText(text: titleLabel.text!)
        speechAndText(text: descriptionTextView.text)
        speechAndText(text: objectToVoiceTitleLabel.text!)
        speechAndText(text: objectToVoiceTDescriptionTextView.text)
        speechAndText(text: moneyIdentifierTitleLabel.text!)
        speechAndText(text: moneyIdentifierDescriptionTextView.text)
    }
    override func viewWillDisappear(_ animated: Bool) {
        navigationController?.navigationBar.prefersLargeTitles = true
        navigationController?.navigationBar.barTintColor = #colorLiteral(red: 0.5405443149, green: 0.1378519087, blue: 0.8, alpha: 1)
        speechSynthesizer.stopSpeaking(at: .immediate)
    }
    override func viewWillAppear(_ animated: Bool) {
        navigationController?.navigationBar.prefersLargeTitles = false
        navigationController?.navigationBar.barTintColor = #colorLiteral(red: 0.3137254902, green: 0.6784313725, blue: 0.6588235294, alpha: 1)
    }
    let gradientLayer = CAGradientLayer()
    func setUp(){
        view.backgroundColor = .white
        gradientLayer.colors = [#colorLiteral(red: 0.4745098039, green: 0.9450980392, blue: 0.6431372549, alpha: 1).cgColor, #colorLiteral(red: 0.05490196078, green: 0.3607843137, blue: 0.6784313725, alpha: 1).cgColor]
        gradientLayer.startPoint = CGPoint(x: 1, y: 0)
        gradientLayer.endPoint = CGPoint(x: 0, y: 1)
        gradientLayer.frame = self.view.bounds
        self.view.layer.addSublayer(gradientLayer)
        self.view.backgroundColor = .white
        
        
        let swipeDown = UISwipeGestureRecognizer(target: self, action: #selector(respondToSwipeGesture))
        swipeDown.direction = UISwipeGestureRecognizer.Direction.down
        self.view.addGestureRecognizer(swipeDown)
        
        view.addSubview(titleLabel)
        view.addSubview(descriptionTextView)
        view.addSubview(objectToVoiceTitleLabel)
        view.addSubview(objectToVoiceTDescriptionTextView)
        view.addSubview(objectToVoiceButton)
        view.addSubview(moneyIdentifierTitleLabel)
        view.addSubview(moneyIdentifierDescriptionTextView)
        view.addSubview(moneyIdentifierTextTButton)
        
        NSLayoutConstraint.activate([
            titleLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            titleLabel.centerXAnchor.constraint(equalTo: view.safeAreaLayoutGuide.centerXAnchor),
            titleLabel.widthAnchor.constraint(equalTo: view.safeAreaLayoutGuide.widthAnchor, constant: -20),
            titleLabel.heightAnchor.constraint(equalToConstant: 60),
            
            descriptionTextView.topAnchor.constraint(equalTo: titleLabel.bottomAnchor),
            descriptionTextView.centerXAnchor.constraint(equalTo: view.safeAreaLayoutGuide.centerXAnchor),
            descriptionTextView.widthAnchor.constraint(equalTo: view.safeAreaLayoutGuide.widthAnchor, constant: -20),
            descriptionTextView.heightAnchor.constraint(equalToConstant: 60),
            
            objectToVoiceTitleLabel.topAnchor.constraint(equalTo: descriptionTextView.bottomAnchor),
            objectToVoiceTitleLabel.centerXAnchor.constraint(equalTo: view.safeAreaLayoutGuide.centerXAnchor),
            objectToVoiceTitleLabel.widthAnchor.constraint(equalTo: view.safeAreaLayoutGuide.widthAnchor, constant: -20),
            objectToVoiceTitleLabel.heightAnchor.constraint(equalToConstant: 30),
            
            objectToVoiceTDescriptionTextView.topAnchor.constraint(equalTo: objectToVoiceTitleLabel.bottomAnchor),
            objectToVoiceTDescriptionTextView.centerXAnchor.constraint(equalTo: view.safeAreaLayoutGuide.centerXAnchor),
            objectToVoiceTDescriptionTextView.widthAnchor.constraint(equalTo: view.safeAreaLayoutGuide.widthAnchor, constant: -20),
            objectToVoiceTDescriptionTextView.heightAnchor.constraint(equalToConstant: 40),
            
            
            objectToVoiceButton.topAnchor.constraint(equalTo: objectToVoiceTDescriptionTextView.bottomAnchor),
            objectToVoiceButton.centerXAnchor.constraint(equalTo: view.safeAreaLayoutGuide.centerXAnchor),
            objectToVoiceButton.widthAnchor.constraint(equalToConstant: 150),
            objectToVoiceButton.heightAnchor.constraint(equalToConstant: 40),
            
            moneyIdentifierTitleLabel.topAnchor.constraint(equalTo: objectToVoiceButton.bottomAnchor, constant: 20),
            moneyIdentifierTitleLabel.centerXAnchor.constraint(equalTo: view.safeAreaLayoutGuide.centerXAnchor),
            moneyIdentifierTitleLabel.widthAnchor.constraint(equalTo: view.safeAreaLayoutGuide.widthAnchor, constant: -20),
            moneyIdentifierTitleLabel.heightAnchor.constraint(equalToConstant: 30),
            
            moneyIdentifierDescriptionTextView.topAnchor.constraint(equalTo: moneyIdentifierTitleLabel.bottomAnchor),
            moneyIdentifierDescriptionTextView.centerXAnchor.constraint(equalTo: view.safeAreaLayoutGuide.centerXAnchor),
            moneyIdentifierDescriptionTextView.widthAnchor.constraint(equalTo: view.safeAreaLayoutGuide.widthAnchor, constant: -20),
            moneyIdentifierDescriptionTextView.heightAnchor.constraint(equalToConstant: 40),
            
            moneyIdentifierTextTButton.topAnchor.constraint(equalTo: moneyIdentifierDescriptionTextView.bottomAnchor),
            moneyIdentifierTextTButton.centerXAnchor.constraint(equalTo: view.safeAreaLayoutGuide.centerXAnchor),
            moneyIdentifierTextTButton.widthAnchor.constraint(equalToConstant: 150),
            moneyIdentifierTextTButton.heightAnchor.constraint(equalToConstant: 40),
            ])
    }
    @objc func respondToSwipeGesture(gesture: UIGestureRecognizer) {
        if let swipeGesture = gesture as? UISwipeGestureRecognizer {
            switch swipeGesture.direction {
            case UISwipeGestureRecognizer.Direction.down:
                showObjectToTextVC()
            case UISwipeGestureRecognizer.Direction.up:
                showMoneyIdentifierVC()
            default:
                break
            }
        }
    }
    let speechSynthesizer = AVSpeechSynthesizer()
    
    func speechAndText(text: String) {
        let speechUtterance = AVSpeechUtterance(string: text)
        speechSynthesizer.speak(speechUtterance)
        UIView.animate(withDuration: 1.0, delay: 0.0, options: .curveEaseInOut, animations: {
        }, completion: nil)
    }
    @objc func showMoneyIdentifierVC(){
        navigationController?.pushViewController(moneyIdentifierVC(), animated: true)
    }
    @objc func showObjectToTextVC(){
        navigationController?.pushViewController(objectToVoice(), animated: true)
    }
}
class SignToTextViewController: UIViewController, AVCaptureVideoDataOutputSampleBufferDelegate, AVCaptureMetadataOutputObjectsDelegate{
    let introductionPage: UIView = {
        let view = UIView()
        view.translatesAutoresizingMaskIntoConstraints = false
        view.backgroundColor = #colorLiteral(red: 0.3935145548, green: 0.06258582629, blue: 0.6538736192, alpha: 1)
        view.layer.cornerRadius = 15
        view.layer.masksToBounds = true
        view.alpha = 1
        return view
    }()
    let introductionTitleView: UIView = {
        let view = UIView()
        view.translatesAutoresizingMaskIntoConstraints = false
        view.backgroundColor = #colorLiteral(red: 0.3935145548, green: 0.06258582629, blue: 0.6538736192, alpha: 1)
        return view
    }()
    let introductionTitle: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = UIFont.boldSystemFont(ofSize: 30)
        label.textColor = .white
        label.text = "ASL to Text"
        return label
    }()
    let introductionScrollView: UIScrollView = {
        let scrollView = UIScrollView()
        scrollView.translatesAutoresizingMaskIntoConstraints = false
        scrollView.alwaysBounceVertical = true
        scrollView.isScrollEnabled = true
        return scrollView
    }()
    let contentView: UIView = {
        let view = UIView()
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    let introductionTextView: UITextView = {
        let textView = UITextView()
        textView.translatesAutoresizingMaskIntoConstraints = false
        textView.backgroundColor = .clear
        textView.isEditable = false
        textView.isScrollEnabled = false
        
        textView.text = "Today over 5% of the world's population (466 million people) suffers disabling hearing loss out of which are 432 million adults and 34 million children. It is estimated that by the year 2050 over 900 million people – or 1 out of every 10 people – will have disabling hearing loss. \nBeing a part of this community it is our responsiblity to be able to assist these indivuals. Learning the ASL - American Sign Language - is the first step that should be taken to enable flawless communication.\nThis is an ASL translator that incoorprates CoreML and the Vision Kit to translate signs to text. \nMake any ASL sign A-Z and the application will translate it for you. The center buttons will show the first two predictions.\n\n Try writing your name! Click on ... to show all predictions and select the desired letter. Click on the ✎ button to bring up the backspace and spacebar button. "
        textView.font = UIFont.systemFont(ofSize: 21)
        textView.textColor = .white
        return textView
    }()
    let introductionLabel2: UILabel = {
        let label = UILabel()
        label.textColor = .white
        label.font = UIFont.boldSystemFont(ofSize: 21)
        label.text = "dsdasdasad"
        return label
    }()
    let introductionTextView2: UITextView = {
        let textView = UITextView()
        textView.translatesAutoresizingMaskIntoConstraints = false
        textView.backgroundColor = .clear
        textView.isEditable = false
        textView.isScrollEnabled = false
        textView.text = ""
        textView.font = UIFont.systemFont(ofSize: 21)
        textView.textColor = .white
        return textView
    }()
    let introductionPredictionImage: UIImageView  = {
        let image = UIImageView()
        image.translatesAutoresizingMaskIntoConstraints = false
        image.backgroundColor = .white
        return image
    }()
    
    let introductionButton: UIButton = {
        let button = UIButton()
        button.translatesAutoresizingMaskIntoConstraints = false
        button.setTitle("Let's Go", for: .normal)
        button.setTitleColor(.white, for: .normal)
        button.titleLabel?.font = UIFont.boldSystemFont(ofSize: 20)
        button.backgroundColor = #colorLiteral(red: 0.3039383562, green: 0.1378519087, blue: 0.8, alpha: 1)
        button.addTarget(self, action: #selector(dismissView), for: .touchUpInside)
        return button
    }()
    let textInputContainer: UIView = {
        let view = UIView()
        view.translatesAutoresizingMaskIntoConstraints = false
        view.backgroundColor = #colorLiteral(red: 0.5405443149, green: 0.1378519087, blue: 0.8, alpha: 1)
        return view
    }()
    let textInput: UITextField = {
        let textField = UITextField()
        textField.translatesAutoresizingMaskIntoConstraints = false
        textField.placeholder = "Translate....."
        textField.textColor = .white
        return textField
    }()
    let predictionLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = UIFont.boldSystemFont(ofSize: 12)
        label.textColor = .lightGray
        label.textAlignment = .center
        label.text = "PREDICTIONS"
        return label
    }()
    let buttonContainer: UIView = {
        let view = UIView()
        view.translatesAutoresizingMaskIntoConstraints = false
        view.layer.masksToBounds = true
        view.layer.cornerRadius = 30
        return view
    }()
    let identifierButton: UIButton = {
        let button = UIButton()
        button.backgroundColor = #colorLiteral(red: 0.5405443149, green: 0.1378519087, blue: 0.8, alpha: 1)
        button.titleLabel?.font = UIFont(name: "HelveticaNeue-Bold", size: 20)
        button.setTitle("_", for: .normal)
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()
    let secondIdentifierButton: UIButton = {
        let button = UIButton()
        button.backgroundColor = #colorLiteral(red: 0.5405443149, green: 0.1378519087, blue: 0.8, alpha: 1)
        button.setTitle("_", for: .normal)
        button.titleLabel?.font = UIFont(name: "HelveticaNeue-Bold", size: 20)
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()
    let predictionsButton : UIButton = {
        let button = UIButton()
        button.backgroundColor = #colorLiteral(red: 0.5405443149, green: 0.1378519087, blue: 0.8, alpha: 1)
        button.setTitle("...", for: .normal)
        button.addTarget(self, action: #selector(showPredictionButtons), for: .touchUpInside)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.layer.cornerRadius = 30
        button.titleLabel?.font = UIFont.boldSystemFont(ofSize: 20)
        return button
    }()
    let firstObservationButton: UIButton = {
        let button = UIButton()
        button.backgroundColor = #colorLiteral(red: 0.5405443149, green: 0.1378519087, blue: 0.8, alpha: 1)
        button.setTitle("-", for: .normal)
        button.addTarget(self, action: #selector(addText), for: .touchUpInside)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.layer.cornerRadius = 30
        button.titleLabel?.font = UIFont.boldSystemFont(ofSize: 20)
        return button
    }()
    let secondObservationButton: UIButton = {
        let button = UIButton()
        button.backgroundColor = #colorLiteral(red: 0.5405443149, green: 0.1378519087, blue: 0.8, alpha: 1)
        button.setTitle("-", for: .normal)
        button.addTarget(self, action: #selector(addText), for: .touchUpInside)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.layer.cornerRadius = 30
        button.titleLabel?.font = UIFont.boldSystemFont(ofSize: 20)
        return button
    }()
    let thirdObservationButton: UIButton = {
        let button = UIButton()
        button.backgroundColor = #colorLiteral(red: 0.5405443149, green: 0.1378519087, blue: 0.8, alpha: 1)
        button.setTitle("-", for: .normal)
        button.addTarget(self, action: #selector(addText), for: .touchUpInside)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.layer.cornerRadius = 30
        button.titleLabel?.font = UIFont.boldSystemFont(ofSize: 20)

        return button
    }()
    let fourthObservationButton: UIButton = {
        let button = UIButton()
        button.backgroundColor = #colorLiteral(red: 0.5405443149, green: 0.1378519087, blue: 0.8, alpha: 1)
        button.setTitle("-", for: .normal)
        button.addTarget(self, action: #selector(addText), for: .touchUpInside)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.layer.cornerRadius = 30
        button.titleLabel?.font = UIFont.boldSystemFont(ofSize: 20)
        return button
    }()
    let toolButton: UIButton = {
        let button = UIButton()
        button.backgroundColor = #colorLiteral(red: 0.5405443149, green: 0.1378519087, blue: 0.8, alpha: 1)
        button.setTitle("✎", for: .normal)
        button.addTarget(self, action: #selector(showTools), for: .touchUpInside)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.layer.cornerRadius = 30
        button.titleLabel?.font = UIFont.boldSystemFont(ofSize: 20)
        return button
    }()
    let backspaceButton: UIButton = {
        let button = UIButton()
        button.backgroundColor = #colorLiteral(red: 0.5405443149, green: 0.1378519087, blue: 0.8, alpha: 1)
        button.setTitle("⌫", for: .normal)
        button.addTarget(self, action: #selector(deleteText), for: .touchUpInside)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.layer.cornerRadius = 30
        button.titleLabel?.font = UIFont.boldSystemFont(ofSize: 20)
        return button
    }()
    let spacebarButton: UIButton = {
        let button = UIButton()
        button.backgroundColor = #colorLiteral(red: 0.5405443149, green: 0.1378519087, blue: 0.8, alpha: 1)
        button.setTitle("␣", for: .normal)
        button.addTarget(self, action: #selector(addSpace), for: .touchUpInside)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.layer.cornerRadius = 30
        button.titleLabel?.font = UIFont.boldSystemFont(ofSize: 20)
        return button
    }()
    var previewLayer: AVCaptureVideoPreviewLayer?
    var isToolButtonEnabled = false
    var isPredictionsButtonEnabled = false
    var predictionsButtonWidth: NSLayoutConstraint?
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "ASL"
        view.backgroundColor = .white
        setUpCamera()
        setupUI()
        setUpIntroUI()
        topLayoutIntroPage.constant = 0
        UIView.animate(withDuration: 0.5, delay: 0.0, animations: {
            self.introductionPage.frame = self.introductionPage.frame.offsetBy(dx: 0, dy: -30)
            self.introductionPage.alpha = 1
        })
    }
    func setUpCamera(){
        let captureSession = AVCaptureSession()
        captureSession.sessionPreset = .photo
        guard let captureDevice = AVCaptureDevice.default(for: .video) else { return }
        guard let input = try? AVCaptureDeviceInput(device: captureDevice) else { return }
        captureSession.addInput(input)
        captureSession.startRunning()
        previewLayer = AVCaptureVideoPreviewLayer(session: captureSession)
        view.layer.addSublayer(previewLayer!)
        previewLayer!.frame = view.frame
        previewLayer!.videoGravity = .resizeAspectFill
        previewLayer?.connection!.videoOrientation = .landscapeRight
        let dataOutput = AVCaptureVideoDataOutput()
        dataOutput.setSampleBufferDelegate(self, queue: DispatchQueue(label: "videoQueue"))
        captureSession.addOutput(dataOutput)
    }
    var topLayoutIntroPage :NSLayoutConstraint!
    func setUpIntroUI(){
        view.addSubview(introductionPage)
        introductionPage.addSubview(introductionTitleView)
        introductionTitleView.addSubview(introductionTitle)
        introductionPage.addSubview(introductionScrollView)
        introductionScrollView.addSubview(contentView)
        contentView.addSubview(introductionTextView)
        introductionPage.addSubview(introductionButton)
        
        topLayoutIntroPage = introductionPage.centerYAnchor.constraint(equalTo: view.safeAreaLayoutGuide.centerYAnchor, constant: 1000)

        
        NSLayoutConstraint.activate([
            introductionPage.centerXAnchor.constraint(equalTo: view.safeAreaLayoutGuide.centerXAnchor),
            introductionPage.widthAnchor.constraint(equalTo: view.safeAreaLayoutGuide.widthAnchor, constant: -50),
            introductionPage.heightAnchor.constraint(equalTo: view.safeAreaLayoutGuide.heightAnchor, constant: -50),
        topLayoutIntroPage,
            
            introductionTitleView.topAnchor.constraint(equalTo: introductionPage.topAnchor),
            introductionTitleView.centerXAnchor.constraint(equalTo: introductionPage.centerXAnchor),
            introductionTitleView.widthAnchor.constraint(equalTo: introductionPage.widthAnchor),
            introductionTitleView.heightAnchor.constraint(equalToConstant: 60),
            
            introductionTitle.topAnchor.constraint(equalTo: introductionTitleView.topAnchor),
            introductionTitle.centerXAnchor.constraint(equalTo: introductionTitleView.centerXAnchor),
            introductionTitle.widthAnchor.constraint(equalTo: introductionTitleView.widthAnchor, constant: -18),
            introductionTitle.heightAnchor.constraint(equalToConstant: 60),
            
            introductionScrollView.topAnchor.constraint(equalTo: introductionTitle.bottomAnchor),
            introductionScrollView.centerXAnchor.constraint(equalTo: introductionPage.centerXAnchor),
            introductionScrollView.widthAnchor.constraint(equalTo: introductionPage.widthAnchor, constant: -18),
            introductionScrollView.heightAnchor.constraint(equalTo: introductionPage.heightAnchor, constant: -60),
            
            contentView.topAnchor.constraint(equalTo: introductionScrollView.topAnchor),
            contentView.centerXAnchor.constraint(equalTo: introductionScrollView.centerXAnchor),
            contentView.widthAnchor.constraint(equalTo: introductionScrollView.widthAnchor),
            contentView.heightAnchor.constraint(equalToConstant: 1000),
            
            introductionTextView.topAnchor.constraint(equalTo: contentView.topAnchor),
            introductionTextView.centerXAnchor.constraint(equalTo: contentView.centerXAnchor),
            introductionTextView.widthAnchor.constraint(equalTo: contentView.widthAnchor, constant: -18),
            introductionTextView.heightAnchor.constraint(equalToConstant: 600),

            introductionButton.bottomAnchor.constraint(equalTo: introductionPage.bottomAnchor),
            introductionButton.centerXAnchor.constraint(equalTo: introductionPage.centerXAnchor),
            introductionButton.widthAnchor.constraint(equalTo: introductionPage.widthAnchor),
            introductionButton.heightAnchor.constraint(equalToConstant: 50),
            ])
        introductionPage.alpha = 0
    }
    func setupUI(){
        view.addSubview(textInputContainer)
        textInputContainer.addSubview(textInput)
        
        view.addSubview(predictionLabel)
        
        view.addSubview(buttonContainer)
        buttonContainer.addSubview(identifierButton)
        buttonContainer.addSubview(secondIdentifierButton)
        
        view.addSubview(toolButton)
        view.addSubview(backspaceButton)
        view.addSubview(spacebarButton)

        view.addSubview(predictionsButton)
        view.addSubview(firstObservationButton)
        view.addSubview(secondObservationButton)
        view.addSubview(thirdObservationButton)
        view.addSubview(fourthObservationButton)
        
        predictionsButtonWidth =  predictionsButton.widthAnchor.constraint(equalToConstant: 60)
        //MARK: CONSTRAINTS
        NSLayoutConstraint.activate([
            
            //TEXT INPUT CONTAINER
            textInputContainer.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            textInputContainer.centerXAnchor.constraint(equalTo: view.safeAreaLayoutGuide.centerXAnchor),
            textInputContainer.widthAnchor.constraint(equalTo: view.safeAreaLayoutGuide.widthAnchor),
            textInputContainer.heightAnchor.constraint(equalToConstant: 60),
            
            //TEXT INPUT
            textInput.topAnchor.constraint(equalTo: textInputContainer.topAnchor),
            textInput.centerXAnchor.constraint(equalTo: textInputContainer.centerXAnchor),
            textInput.widthAnchor.constraint(equalTo: textInputContainer.widthAnchor, constant: -10),
            textInput.heightAnchor.constraint(equalTo: textInputContainer.heightAnchor),
            
            //BUTTON CONTAINER
            buttonContainer.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -5),
            buttonContainer.centerXAnchor.constraint(equalTo: view.safeAreaLayoutGuide.centerXAnchor),
            buttonContainer.widthAnchor.constraint(equalToConstant: 200),
            buttonContainer.heightAnchor.constraint(equalToConstant: 60),

            //FIRST OBSERVATION BUTTON
            identifierButton.bottomAnchor.constraint(equalTo: buttonContainer.bottomAnchor),
            identifierButton.leftAnchor.constraint(equalTo: buttonContainer.leftAnchor),
            identifierButton.widthAnchor.constraint(equalTo: buttonContainer.widthAnchor, multiplier: 1/2),
            identifierButton.heightAnchor.constraint(equalTo: buttonContainer.heightAnchor),
            
            //SECOND OBSERVATION BUTTON
            secondIdentifierButton.bottomAnchor.constraint(equalTo: buttonContainer.bottomAnchor),
            secondIdentifierButton.leftAnchor.constraint(equalTo: identifierButton.rightAnchor),
            secondIdentifierButton.widthAnchor.constraint(equalTo: buttonContainer.widthAnchor, multiplier: 1/2),
            secondIdentifierButton.heightAnchor.constraint(equalTo: buttonContainer.heightAnchor),
            
            //PREDICTION LABEL
            predictionLabel.bottomAnchor.constraint(equalTo: buttonContainer.topAnchor, constant: -5),
            predictionLabel.centerXAnchor.constraint(equalTo: view.safeAreaLayoutGuide.centerXAnchor),
            predictionLabel.widthAnchor.constraint(equalToConstant: 200),
            predictionLabel.heightAnchor.constraint(equalToConstant: 20),
            
            //TOOL BUTTON
            toolButton.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -5),
            toolButton.rightAnchor.constraint(equalTo: view.rightAnchor, constant: -5),
            toolButton.widthAnchor.constraint(equalToConstant: 60),
            toolButton.heightAnchor.constraint(equalToConstant: 60),
            
            //BACKSPACE BUTTON
            backspaceButton.bottomAnchor.constraint(equalTo: toolButton.topAnchor, constant: -16),
            backspaceButton.rightAnchor.constraint(equalTo: view.rightAnchor, constant: -5),
            backspaceButton.widthAnchor.constraint(equalToConstant: 60),
            backspaceButton.heightAnchor.constraint(equalToConstant: 60),
        
            //SPACEBAR BUTTON
            spacebarButton.bottomAnchor.constraint(equalTo: backspaceButton.topAnchor, constant: -16),
            spacebarButton.rightAnchor.constraint(equalTo: view.rightAnchor, constant: -5),
            spacebarButton.widthAnchor.constraint(equalToConstant: 60),
            spacebarButton.heightAnchor.constraint(equalToConstant: 60),
            
            //predictionsButton
            predictionsButtonWidth!,
            predictionsButton.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -5),
            predictionsButton.leftAnchor.constraint(equalTo: view.leftAnchor, constant: 5),
            predictionsButton.heightAnchor.constraint(equalToConstant: 60),
            
            //firstObservationButton
            firstObservationButton.bottomAnchor.constraint(equalTo: toolButton.topAnchor, constant: -16),
            firstObservationButton.leftAnchor.constraint(equalTo: view.leftAnchor, constant: 5),
            firstObservationButton.widthAnchor.constraint(equalToConstant: 60),
            firstObservationButton.heightAnchor.constraint(equalToConstant: 60),
            
            //secondObservationButton
            secondObservationButton.bottomAnchor.constraint(equalTo: firstObservationButton.topAnchor, constant: -16),
            secondObservationButton.leftAnchor.constraint(equalTo: view.leftAnchor, constant: 5),
            secondObservationButton.widthAnchor.constraint(equalToConstant: 60),
            secondObservationButton.heightAnchor.constraint(equalToConstant: 60),
            
            //thirdObservationButton
            thirdObservationButton.bottomAnchor.constraint(equalTo: secondObservationButton.topAnchor, constant: -16),
            thirdObservationButton.leftAnchor.constraint(equalTo: view.leftAnchor, constant: 5),
            thirdObservationButton.widthAnchor.constraint(equalToConstant: 60),
            thirdObservationButton.heightAnchor.constraint(equalToConstant: 60),
            
            //fourthObservationButton
            fourthObservationButton.bottomAnchor.constraint(equalTo: thirdObservationButton.topAnchor, constant: -16),
            fourthObservationButton.leftAnchor.constraint(equalTo: view.leftAnchor, constant: 5),
            fourthObservationButton.widthAnchor.constraint(equalToConstant: 60),
            fourthObservationButton.heightAnchor.constraint(equalToConstant: 60)
            ])
        backspaceButton.isHidden = true
        backspaceButton.alpha = 0

        spacebarButton.isHidden = true
        spacebarButton.alpha = 0
        
        firstObservationButton.isHidden = true
        firstObservationButton.alpha = 0

        secondObservationButton.isHidden = true
        secondObservationButton.alpha = 0
        
        thirdObservationButton.isHidden = true
        thirdObservationButton.alpha = 0
        
        fourthObservationButton.isHidden = true
        fourthObservationButton.alpha = 0
    }
    func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
        guard let pixelBuffer: CVPixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) else { return }
        guard let model = try? VNCoreMLModel(for: ASL().model) else { return }
        let request = VNCoreMLRequest(model: model) { (finishedReq, err) in
            guard let results = finishedReq.results as? [VNClassificationObservation] else { return }
            guard let firstObservation = results.first else { return }
            let secondObservation = results[1]
            let thirdObservation = results[2]
            let fourthObservation = results[3]
            DispatchQueue.main.async {
                if firstObservation.confidence > 0.6{
                    self.identifierButton.setTitle("\(firstObservation.identifier)", for: .normal)
                    self.secondIdentifierButton.setTitle(secondObservation.identifier, for: .normal)
                    self.firstObservationButton.setTitle("\(firstObservation.identifier)", for: .normal)
                    self.secondObservationButton.setTitle(secondObservation.identifier, for: .normal)
                    self.thirdObservationButton.setTitle("\(thirdObservation.identifier)", for: .normal)
                    self.fourthObservationButton.setTitle(fourthObservation.identifier, for: .normal)
                    UIView.animate(withDuration: 1.0, animations: {
                        let red: CGFloat = CGFloat(255 * firstObservation.confidence)
                        self.identifierButton.layer.backgroundColor = UIColor(red: red/255, green: 20/255, blue: 255/255, alpha: 1).cgColor
                        let secondRed: CGFloat = CGFloat(255 * secondObservation.confidence)
                        self.secondIdentifierButton.layer.backgroundColor = UIColor(red: secondRed/255, green: 20/255, blue: 255/255, alpha: 1).cgColor
                    })
                }
            }
        }
        try? VNImageRequestHandler(cvPixelBuffer: pixelBuffer, options: [:]).perform([request])
    }
    @objc func showTools(){
        if isToolButtonEnabled == false{
            UIView.animate(withDuration: 0.5, animations: {
                self.toolButton.backgroundColor = .white
                self.toolButton.setTitle("×", for: .normal)
                self.toolButton.setTitleColor(.black, for: .normal)
                self.backspaceButton.isHidden = false
                self.spacebarButton.isHidden = false
                self.spacebarButton.alpha = 1
                self.backspaceButton.alpha = 1
            })
            isToolButtonEnabled = true
        }
        else if isToolButtonEnabled == true{
            UIView.animate(withDuration: 0.5, animations: {
                self.toolButton.backgroundColor = #colorLiteral(red: 0.5405443149, green: 0.1378519087, blue: 0.8, alpha: 1)
                self.toolButton.setTitle("✎", for: .normal)
                self.toolButton.setTitleColor(.white, for: .normal)
                self.spacebarButton.alpha = 0
                self.spacebarButton.isHidden = true
                self.backspaceButton.alpha = 0
                self.backspaceButton.isHidden = true
            })
            isToolButtonEnabled = false
        }
    }
    @objc func showPredictionButtons(){
        if isPredictionsButtonEnabled == false{
            UIView.animate(withDuration: 0.5, animations: {
                self.predictionsButton.backgroundColor = .white
                self.predictionsButtonWidth?.constant = 170
                self.predictionsButton.setTitle("× Predictions", for: .normal)
                self.predictionsButton.setTitleColor(.black, for: .normal)
                self.firstObservationButton.alpha = 1
                self.secondObservationButton.alpha = 1
                self.thirdObservationButton.alpha = 1
                self.fourthObservationButton.alpha = 1
                self.firstObservationButton.isHidden = false
                self.secondObservationButton.isHidden = false
                self.thirdObservationButton.isHidden = false
                self.fourthObservationButton.isHidden = false
            })
            isPredictionsButtonEnabled = true
        }
        else if isPredictionsButtonEnabled == true{
            UIView.animate(withDuration: 0.5, animations: {
                self.predictionsButtonWidth?.constant = 60
                self.firstObservationButton.alpha = 0
                self.secondObservationButton.alpha = 0
                self.thirdObservationButton.alpha = 0
                self.fourthObservationButton.alpha = 0
                self.firstObservationButton.isHidden = true
                self.secondObservationButton.isHidden = true
                self.thirdObservationButton.isHidden = true
                self.fourthObservationButton.isHidden = true
                self.predictionsButton.setTitle("...", for: .normal)
                self.predictionsButton.backgroundColor = #colorLiteral(red: 0.5405443149, green: 0.1378519087, blue: 0.8, alpha: 1)
                self.predictionsButton.setTitleColor(.white, for: .normal)
            })
            isPredictionsButtonEnabled = false
        }
    }
    @objc func dismissView(sender: UIButton!){
        UIView.animate(withDuration: 2.0, animations: {
            self.introductionPage.frame = self.introductionPage.frame.insetBy(dx: 0, dy: 1000)
            self.introductionPage.alpha = 0
            self.introductionPage.isHidden = true
        })
    }
    
    @objc func addText(_ sender: UIButton){
        textInput.text = textInput.text! + (sender.titleLabel?.text)!
    }
    @objc func deleteText(){
        textInput.text = String((textInput.text?.dropLast())!)
    }
    @objc func addSpace(){
        textInput.text = textInput.text! + " "
    }
}

class moneyIdentifierVC: UIViewController, AVCaptureVideoDataOutputSampleBufferDelegate {
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Money Identifier"
        speechAndText(text: "Place a dollar bill infront of the camera and I'll it's worth")
        view.backgroundColor = .white
        setUpCamera()
    }
    var previewLayer: AVCaptureVideoPreviewLayer?
    func setUpCamera(){
        let captureSession = AVCaptureSession()
        captureSession.sessionPreset = .photo
        guard let captureDevice = AVCaptureDevice.default(for: .video) else { return }
        guard let input = try? AVCaptureDeviceInput(device: captureDevice) else { return }
        captureSession.addInput(input)
        captureSession.startRunning()
        previewLayer = AVCaptureVideoPreviewLayer(session: captureSession)
        view.layer.addSublayer(previewLayer!)
        previewLayer!.frame = view.frame
        previewLayer!.videoGravity = .resizeAspectFill
        previewLayer?.connection!.videoOrientation = .landscapeRight
        let dataOutput = AVCaptureVideoDataOutput()
        dataOutput.setSampleBufferDelegate(self, queue: DispatchQueue(label: "videoQueue"))
        captureSession.addOutput(dataOutput)
    }
    func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
        guard let pixelBuffer: CVPixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) else { return }
        guard let model = try? VNCoreMLModel(for: MoneyClassifier().model) else { return }
        let request = VNCoreMLRequest(model: model) { (finishedReq, err) in
            guard let results = finishedReq.results as? [VNClassificationObservation] else { return }
            guard let firstObservation = results.first else { return }
            print(firstObservation.identifier, firstObservation.confidence)
            DispatchQueue.main.async {
                if firstObservation.confidence > 0.7{
                    self.speechAndText(text:"That's a" + firstObservation.identifier + " dollar bill.")
                }
            }
        }
        try? VNImageRequestHandler(cvPixelBuffer: pixelBuffer, options: [:]).perform([request])
    }
    let speechSynthesizer = AVSpeechSynthesizer()
    func speechAndText(text: String) {
        if speechSynthesizer.isSpeaking == false{
            let speechUtterance = AVSpeechUtterance(string: text)
            speechSynthesizer.speak(speechUtterance)
            UIView.animate(withDuration: 1.0, delay: 0.0, options: .curveEaseInOut, animations: {
            }, completion: nil)
        }
    }
    
}
class objectToVoice: UIViewController, AVCaptureVideoDataOutputSampleBufferDelegate {
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Object to Voice"
        view.backgroundColor = .white
        speechAndText(text: "Place an object infront of the camera and I'll tell you what it is")
        setUpCamera()
    }
    var previewLayer: AVCaptureVideoPreviewLayer?
    func setUpCamera(){
        let captureSession = AVCaptureSession()
        captureSession.sessionPreset = .photo
        guard let captureDevice = AVCaptureDevice.default(for: .video) else { return }
        guard let input = try? AVCaptureDeviceInput(device: captureDevice) else { return }
        captureSession.addInput(input)
        captureSession.startRunning()
        previewLayer = AVCaptureVideoPreviewLayer(session: captureSession)
        view.layer.addSublayer(previewLayer!)
        previewLayer!.frame = view.frame
        previewLayer!.videoGravity = .resizeAspectFill
        previewLayer?.connection!.videoOrientation = .landscapeRight
        let dataOutput = AVCaptureVideoDataOutput()
        dataOutput.setSampleBufferDelegate(self, queue: DispatchQueue(label: "videoQueue"))
        captureSession.addOutput(dataOutput)
    }
    func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
        guard let pixelBuffer: CVPixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) else { return }
        guard let model = try? VNCoreMLModel(for:MobileNet().model) else { return }
        let request = VNCoreMLRequest(model: model) { (finishedReq, err) in
            guard let results = finishedReq.results as? [VNClassificationObservation] else { return }
            guard let firstObservation = results.first else { return }
            print(firstObservation.identifier, firstObservation.confidence)
            DispatchQueue.main.async {
                if firstObservation.confidence > 0.3{
                     self.speechAndText(text:"I see a" + firstObservation.identifier)
                }
            }
        }
        try? VNImageRequestHandler(cvPixelBuffer: pixelBuffer, options: [:]).perform([request])
    }
    let speechSynthesizer = AVSpeechSynthesizer()
    func speechAndText(text: String) {
        if speechSynthesizer.isSpeaking == false{
            let speechUtterance = AVSpeechUtterance(string: text)
            speechSynthesizer.speak(speechUtterance)
            UIView.animate(withDuration: 1.0, delay: 0.0, options: .curveEaseInOut, animations: {
            }, completion: nil)
        }
    }
}


let main = mainViewController()
let nav = navigationController(rootViewController: main)
nav.preferredContentSize = CGSize(width: 600, height: 600)
PlaygroundPage.current.liveView = nav
PlaygroundPage.current.needsIndefiniteExecution = true
